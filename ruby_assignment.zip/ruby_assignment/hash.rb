class Hashh
	def func
    puts "Enter has value like a=>b"
    str=gets.chomp
   arr=str.split('=>')    
    arr.each {|key, value| puts "#{arr[0]} is a #{arr[1]}" }
   end
   
end

ob=Hashh.new
ob.func