class Vehicle
@wheels
@color
@price
@brand
def initialize(wheels,color,price)
  @wheels=wheels
  @color=color
  @price=price  
end
 
def module
 puts "This vehicle has #{@wheels}  wheels and  #{@color} color "
 
end
end
class Bus<Vehicle
  def initialize(wheels,color,length,seats,price)
  super(wheels,color,price)
  @length=length
  @seats=seats

  end
end

class Car<Vehicle
  def initialize(wheels,color,length,seats,price)
  super(wheels,color,price)
  @length=length
  @seats=seats

  end
end

emp = Vehicle.new(100,"red",20000)
emp.module
ob1=Bus.new(100,"green",10,200,15000)
ob1.module

ob2=Car.new(10,"grey",10,10,30000)
ob2.module